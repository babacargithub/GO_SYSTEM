<?php

namespace GO\MainBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use GO\MainBundle\Validator\ValidePhone;

/**
 * Client
 *
 */
abstract class Client
{
    
}

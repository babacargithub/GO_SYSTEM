<?php

namespace GO\CaravaneBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Reservation
 *
 * @ORM\Table(name="reservation", uniqueConstraints={@ORM\UniqueConstraint(name="reservation_unique", columns={"client", "depart"})}, indexes={@ORM\Index(name="fk_depart", columns={"depart"}), @ORM\Index(name="id", columns={"client"}), @ORM\Index(name="id_agent", columns={"agent"}), @ORM\Index(name="point_dep", columns={"point_dep"}), @ORM\Index(name="id_des", columns={"des"}), @ORM\Index(name="confirme", columns={"confirme"})})
 * @ORM\Entity(repositoryClass="GO\CaravaneBundle\Entity\ReservationRepository")
 */
class Reservation
{
    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="datetime", nullable=true)
     */
    private $date;

    /**
     * @var boolean
     *
     * @ORM\Column(name="confirme", type="boolean", nullable=false)
     */
    private $confirme;
    /**
     * @var boolean
     *
     * @ORM\Column(name="paye", type="boolean", nullable=false)
     */
    private $paye=false;

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \GO\CaravaneBundle\Entity\PointDepart
     *
     * @ORM\ManyToOne(targetEntity="GO\CaravaneBundle\Entity\PointDepart")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="point_dep", referencedColumnName="id")
     * })
     */
    private $pointDep;

    /**
     * @var \GO\CaravaneBundle\Entity\Payer
     *
     * @ORM\OneToOne(targetEntity="GO\CaravaneBundle\Entity\Payer", cascade={"remove"})
      
     */
    private $paiement;
    /**
     * @var \GO\CaravaneBundle\Entity\Client
     *
     * @ORM\ManyToOne(targetEntity="GO\CaravaneBundle\Entity\Client", inversedBy="reservations")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="client", referencedColumnName="id")
     * })
     */
    private $client;

    /**
     * @var \GO\CaravaneBundle\Entity\Destination
     *
     * @ORM\ManyToOne(targetEntity="GO\CaravaneBundle\Entity\Destination")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="des", referencedColumnName="id", nullable=false)
     * })
     */
    private $des;

    /**
     * @var \GO\CaravaneBundle\Entity\Depart
     *
     * @ORM\ManyToOne(targetEntity="GO\CaravaneBundle\Entity\Depart")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="depart", referencedColumnName="id")
     * })
     */
    private $depart;

    /**
     * @var \GO\CaravaneBundle\Entity\User
     *
     * @ORM\ManyToOne(targetEntity="GO\CaravaneBundle\Entity\User")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="agent", referencedColumnName="id")
     * })
     */
    private $agent;



    /**
     * Set date
     *
     * @param \DateTime $date
     * @return Reservation
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime 
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set confirmeRes
     *
     * @param boolean $confirmeRes
     * @return Reservation
     */
    public function setConfirme($confirmeRes)
    {
        $this->confirme = $confirmeRes;

        return $this;
    }

    /**
     * Get confirmeRes
     *
     * @return boolean 
     */
    public function getConfirme()
    {
        return $this->confirme;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set pointDep
     *
     * @param \GO\CaravaneBundle\Entity\PointDepart $pointDep
     * @return Reservation
     */
    public function setPointDep(\GO\CaravaneBundle\Entity\PointDepart $pointDep = null)
    {
        $this->pointDep = $pointDep;

        return $this;
    }

    /**
     * Get pointDep
     *
     * @return \GO\CaravaneBundle\Entity\PointDepart 
     */
    public function getPointDep()
    {
        return $this->pointDep;
    }

    /**
     * Set client
     *
     * @param \GO\CaravaneBundle\Entity\Client $client
     * @return Reservation
     */
    public function setClient(\GO\CaravaneBundle\Entity\Client $client = null)
    {
        $this->client = $client;

        return $this;
    }

    /**
     * Get client
     *
     * @return \GO\CaravaneBundle\Entity\Client 
     */
    public function getClient()
    {
        return $this->client;
    }

    /**
     * Set des
     *
     * @param \GO\CaravaneBundle\Entity\Destination $des
     * @return Reservation
     */
    public function setDes(\GO\CaravaneBundle\Entity\Destination $des)
    {
        $this->des = $des;

        return $this;
    }

    /**
     * Get des
     *
     * @return \GO\CaravaneBundle\Entity\Destination 
     */
    public function getDes()
    {
        return $this->des;
    }

    /**
     * Set depart
     *
     * @param \GO\CaravaneBundle\Entity\Depart $depart
     * @return Reservation
     */
    public function setDepart(\GO\CaravaneBundle\Entity\Depart $depart = null)
    {
        $this->depart = $depart;

        return $this;
    }

    /**
     * Get depart
     *
     * @return \GO\CaravaneBundle\Entity\Depart 
     */
    public function getDepart()
    {
        return $this->depart;
    }

    /**
     * Set agent
     *
     * @param \GO\CaravaneBundle\Entity\User $agent
     * @return Reservation
     */
    public function setAgent(\GO\CaravaneBundle\Entity\User $agent = null)
    {
        $this->agent = $agent;

        return $this;
    }

    /**
     * Get agent
     *
     * @return \GO\CaravaneBundle\Entity\User 
     */
    public function getAgent()
    {
        return $this->agent;
    }

    /**
     * Set paye
     *
     * @param boolean $paye
     * @return Reservation
     */
    public function setPaye($paye)
    {
        $this->paye = $paye;

        return $this;
    }

    /**
     * Get paye
     *
     * @return boolean 
     */
    public function getPaye()
    {
        return $this->paye;
    }

    /**
     * Set paiement
     *
     * @param \GO\CaravaneBundle\Entity\Payer $paiement
     * @return Reservation
     */
    public function setPaiement(\GO\CaravaneBundle\Entity\Payer $paiement = null)
    {
        $this->paiement = $paiement;

        return $this;
    }

    /**
     * Get paiement
     *
     * @return \GO\CaravaneBundle\Entity\Payer 
     */
    public function getPaiement()
    {
        return $this->paiement;
    }
}

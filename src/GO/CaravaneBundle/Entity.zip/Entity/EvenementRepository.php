<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace GO\CaravaneBundle\Entity;

use Doctrine\ORM\EntityRepository;
Class EvenementRepository extends EntityRepository{
    //put your code here
    public function getEventsEncours()
    {
        $qb=$this->createQueryBuilder('ev')
                ->where('DATE(ev.dateEnd)>CURRENT_DATE()');
        return $qb;
    }
    
}
